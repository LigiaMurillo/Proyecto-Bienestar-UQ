package proyecto.programacion3.modelo;

public enum Horario {
	
	OCHO_AM_A_DIEZ_AM,
	DIEZ_AM_A_DOCE_PM,
	DOS_PM_A_CUATRO_PM,
	CUATRO_PM_A_SEIS_PM;

}
