package proyecto.programacion3.controlador;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import proyecto.programacion3.modelo.*;
import proyecto.programacion3.utilidades.TipoCredito;
import persistencia.*;
import javafx.util.converter.LocalDateStringConverter;

public class ModelFactoryController {

	private Bienestar bienestar;
	private final int CANTIDADCARACTERESCODIGOCREDITO;

	private static class SingletonHolder {
		private final static ModelFactoryController eINSTANCE = new ModelFactoryController();
	}

	public static ModelFactoryController getInstance(){
		return SingletonHolder.eINSTANCE;
	}

	public ModelFactoryController() {
		super();

		this.CANTIDADCARACTERESCODIGOCREDITO = 5;

		try {
			cargarXML();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public void guardarXML() throws Exception {

		Persistencia.guardarRecursoBienestarXML(bienestar);
	}

	public void cargarXML() {

		this.bienestar = Persistencia.cargarRecursoBienestarXML();
	}

	public Bienestar getBienestar() {
		return bienestar;
	}

	public void setBienestar(Bienestar bienestar) {
		this.bienestar = bienestar;
	}

//	Utilidades -------------------------------------------------------------------------------

	public String generarCodigoAleatorio() {

        String theAlphaNumericS;
        StringBuilder builder = new StringBuilder(CANTIDADCARACTERESCODIGOCREDITO);
        theAlphaNumericS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789";

        for (int m = 0; m <= CANTIDADCARACTERESCODIGOCREDITO; m++) {
        	int myindex = (int)(theAlphaNumericS.length() * Math.random());
        	builder.append(theAlphaNumericS.charAt(myindex));
        }
        return builder.toString();
	}

	public Usuario validarAcceso(String nick, String clave) {
		// TODO Auto-generated method stub
		return this.bienestar.validarInicioSesion(nick, clave);
	}
//	Obtener listas ----------------------------------------------------------------------------

	public ArrayList<Estudiante> obtenerListaEstudiantes(){

		return this.bienestar.getListaEstudiantes();
	}

	public ArrayList<Instructor> obtenerListaInstructores() {

		return this.bienestar.getListaInstructores();
	}

	public ArrayList<Lugar> obtenerListaLugares() {
		// TODO Auto-generated method stub
		return this.bienestar.getListaLugares();
	}

	public ArrayList<Credito> obtenerListaCreditos() {
		// TODO Auto-generated method stub
		return this.bienestar.getListaCreditos();
	}

//	CRUD Estudiantes --------------------------------------------------------------------------

	public boolean agregarEstudiante(String nombreEstudiante, String codigoEstudiante, String usuarioEstudiante, String claveEstudiante) throws Exception {

		if (this.bienestar.agregarEstudiante(nombreEstudiante, codigoEstudiante, usuarioEstudiante, claveEstudiante)){
			guardarXML();
			return true;
		}
		return false;
	}

	public Estudiante buscarEstudiante(String busqueda) {

		return this.bienestar.obtenerEstudiante(busqueda);
	}

	public boolean actualizarEstudiante(String nombreEstudiante, String usuarioEstudiante, String claveEstudiante,
			String cedula) throws Exception {

		if (this.bienestar.actualizarEstudiante(nombreEstudiante, usuarioEstudiante, claveEstudiante, cedula)){
			guardarXML();
			return true;
		}
		return false;
	}

	public boolean eliminarEstudiante(String cedula) throws Exception {

		if (this.bienestar.eliminarEstudiante(cedula)){
			guardarXML();
			return true;
		}
		return false;
	}

//	Crud Instructor -------------------------------------------------------------------------

	public boolean agregarInstructor(String nombreInstructor, String codigoInstructor, String usuarioInstructor,
			String claveInstructor) throws Exception {

		if (this.bienestar.agregarInstructor(nombreInstructor, codigoInstructor, usuarioInstructor, claveInstructor)){
			guardarXML();
			return true;
		}
		return false;
	}

	public Instructor buscarInstructor(String busqueda) {

		return this.bienestar.obtenerInstructor(busqueda);
	}

	public boolean actualizarInstructor(String nombreInstructor, String usuarioInstructor, String claveInstructor,
			String cedulaInstructor) throws Exception {

		if (this.bienestar.actualizarInstructor(cedulaInstructor, nombreInstructor, usuarioInstructor, claveInstructor)){
			guardarXML();
			return true;
		}
		return false;
	}

	public boolean eliminarInstructor(String cedula) throws Exception {

		if (this.bienestar.eliminarInstrctor(cedula)){
			guardarXML();
			return true;
		}
		return false;
	}

//	Crud lugar -------------------------------------------------------------------------------

	public boolean agregarLugar(String nombre, String direccion) throws Exception {
		// TODO Auto-generated method stub
		if (this.bienestar.agregarLugar(nombre, direccion)){
			guardarXML();
			return true;
		}
		return false;
	}

	public Lugar buscarLugar(String busqueda) {
		// TODO Auto-generated method stub
		return this.bienestar.obtenerLugar(busqueda);
	}

	public boolean actualizarLugar(String nombreActualizar, String nombre, String dir) throws Exception {
		// TODO Auto-generated method stub
		if (this.bienestar.actualizarLugar(nombreActualizar, nombre, dir)){
			guardarXML();
			return true;
		}
		return false;
	}

	public boolean eliminarLugar(Lugar lugar) throws Exception {

		if (this.bienestar.eliminarLugar(lugar)){
			guardarXML();
			return true;
		}
		return false;
	}

//	Crud creditos ----------------------------------------------------------------------------

	public boolean agregarCredito(String nombre, int duracion, int cupo, Instructor instructor, String horario,
			Lugar lugar, String homologable, TipoCredito tipoCredito, int costo) throws Exception {

		String codigo = generarCodigoAleatorio();
		if (this.bienestar.agregarCredito(nombre, codigo, duracion, cupo, instructor, horario, lugar,
				homologable, tipoCredito, costo)){
			guardarXML();
			return true;
		}
		return false;
	}

	public Credito buscarCredito(String busqueda) {
		// TODO Auto-generated method stub
		return this.bienestar.obtenerCredito(busqueda);
	}

	public boolean actualizarCredito(String codigo, String nombre, int duracion, int cupo, Instructor instructor,
			String horario, Lugar lugar) throws Exception {
		// TODO Auto-generated method stub
		if (this.bienestar.actualizarCredito(codigo, nombre, duracion, cupo, instructor, horario, lugar)){
			guardarXML();
			return true;
		}
		return false;
	}

	public boolean eliminarCredito(Credito creditoSeleccionado) throws Exception {

		if (this.bienestar.eliminarCredito(creditoSeleccionado)){
			guardarXML();
			return true;
		}
		return false;
	}

//	Transaccional ----------------------------------------------------------------------------

	public boolean registrarCredito(Credito creditoSeleccionado, Estudiante estudiante) throws Exception {

		if (this.bienestar.registrarCreditoEstudiante(creditoSeleccionado, estudiante)){
			guardarXML();
			return true;
		}
		return false;
	}

	public boolean cancelarCredito(Credito creditoRegistradoSeleccionado, Estudiante estudiante) throws Exception {

		if (this.bienestar.cancelarCreditoEstudiante(creditoRegistradoSeleccionado, estudiante)){
			guardarXML();
			return true;
		}
		return false;
	}
}