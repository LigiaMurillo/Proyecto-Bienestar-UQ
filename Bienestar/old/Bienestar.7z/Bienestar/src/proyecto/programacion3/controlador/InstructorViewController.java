package proyecto.programacion3.controlador;

public class InstructorViewController {

}
