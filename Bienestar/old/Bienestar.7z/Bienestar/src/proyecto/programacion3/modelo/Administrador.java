package proyecto.programacion3.modelo;

public class Administrador extends Usuario{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public Administrador() {
		super();
	}

	public Administrador(String nombre, String cedula, String nick, String clave) {
		super(nombre, cedula, nick, clave);

	}
}
