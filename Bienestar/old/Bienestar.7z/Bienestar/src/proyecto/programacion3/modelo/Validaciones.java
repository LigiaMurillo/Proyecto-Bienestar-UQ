package proyecto.programacion3.modelo;

public interface Validaciones {

	public Usuario validarInicioSesion(String usuario, String clave);
}